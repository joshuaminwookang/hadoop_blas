## CSCI 339 Distributed Systems
### Final Project	
#### Josh Kang and Daniel Yu

Compile instructions:

* To compile Java

   make build
   

